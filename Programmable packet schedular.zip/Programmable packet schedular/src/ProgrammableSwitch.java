import java.io.BufferedReader;
import java.io.FileReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class ProgrammableSwitch {


    public static int bandwidth=500;
    public static double fairshare=0.0;
    public static int totalweights_sum=0;
    public static double start_time=System.currentTimeMillis();
    public static void main(String args[]) throws Exception{

        System.out.println("set bandwidth");
        Scanner bandsc=new Scanner(System.in);
        bandwidth=Integer.parseInt(bandsc.next());

        BufferedReader br=new BufferedReader(new FileReader("schalgo.txt"));
        String line="";
        System.out.println("Scheduling algorithms list: ");
        System.out.println();
        while((line=br.readLine())!=null){
            System.out.println(line);

        }
        System.out.println();
        System.out.println("pick an Algorithm..");
        Scanner sc=new Scanner(System.in);
        String algopicked=sc.next();

        ServerSocket serversoc=new ServerSocket(6723);

        SchedulingAlgorithms scheduleAlgos=new SchedulingAlgorithms();





        while(true){

            System.out.println("waiting socket..");
             Socket soc=serversoc.accept();

            System.out.println("in while "+start_time);

            AlgorithmInvokers alg=new AlgorithmInvokers(scheduleAlgos,algopicked,soc,start_time);
            alg.start();

            /*System.out.println("do you want to change the current scheduling algorithm "+algopicked+"? (y/n)");
            Scanner srec=new Scanner(System.in);
            String inp=srec.next();
            if(inp.equals("y")){

                br=new BufferedReader(new FileReader("schalgo.txt"));
                line="";
                System.out.println("Scheduling algorithms list: ");
                System.out.println();
                while((line=br.readLine())!=null){
                    System.out.println(line);

                }
                System.out.println();
                System.out.println("pick an Algorithm..");
                Scanner scnew=new Scanner(System.in);
                algopicked=scnew.next();


            }*/




        }


    }
}
