import java.io.DataOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Random;
import java.util.Scanner;

public class FlowGenerator {


    public static int flow_weight=0;
    public static void main(String args[]) throws Exception {



        System.out.println("enter flow name:");
        Scanner sc=new Scanner(System.in);
        String flow_name=sc.next();

        System.out.println("set flow weight");
        flow_weight=Integer.parseInt(sc.next());

        System.out.println("enter number of packets to be generated...");

        sc=new Scanner(System.in);
        int pkt_count=Integer.parseInt(sc.next());

        System.out.println("enter ip address..");
        sc=new Scanner(System.in);

        String serverip=sc.next();
        Socket mysoc=new Socket(InetAddress.getByName(serverip),6723);
        ObjectOutputStream datasent=new ObjectOutputStream(mysoc.getOutputStream());

        //ObjectInputStream datareceived=new ObjectInputStream(mysoc.getInputStream());
        packets initpac=new packets("",0,0);
        initpac.flow_w=flow_weight;
        datasent.writeObject(initpac);
        //System.out.println("sent weight");
       // String getdata=datareceived.readUTF();
        //System.out.println("received conf... "+getdata);
        //datasent.close();
        //mysoc.close();



        int loopin=0;
        int initsize=100;
        Random rand=new Random();
        //Thread.sleep(1000);
        //mysoc=new Socket(InetAddress.getByName(serverip),6723);
        //datasent=new ObjectOutputStream(mysoc.getOutputStream());
        //datareceived=new ObjectInputStream(mysoc.getInputStream());
        while(loopin<pkt_count){

            System.out.println("loopin count: "+loopin);
            int pkt_size=initsize+rand.nextInt(900);
            packets p=new packets(flow_name,pkt_size,loopin+1);
            datasent.writeObject(p);
            //System.out.println("waiting to receive obj ack");
            //datareceived.readUTF();
            //System.out.println("obj ack receive got next");
            loopin++;
            //Thread.sleep(1000);

        }

        packets pfinal=new packets("done",0,0);
        datasent.writeObject(pfinal);


        datasent.close();
        mysoc.close();
    }
}
