import java.io.Serializable;

//no packets have a size greater bandwidth...
public class packets implements Serializable {

    String fname="";
    int flow_w=-1;
    int psize=-1;
    int pnumber=-1;
    double arrival_time=0;
    double virtual_finish_time=0;
    public packets(String flowname, int pktsize,int packetnumber){

        fname=flowname;
        psize=pktsize;
        pnumber=packetnumber;

    }
}
