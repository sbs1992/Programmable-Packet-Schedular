import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class AlgorithmInvokers extends Thread {
    SchedulingAlgorithms schalgo=null;
    String algoname="";
    Socket soc=null;
    double start_time=0;
    packets prev_pac=null;

    public AlgorithmInvokers(SchedulingAlgorithms sa,String aname, Socket s,double start_timestamp){

        schalgo=sa;
        algoname=aname;
        soc=s;
        start_time=start_timestamp;

    }

    public void run(){

        ObjectInputStream getdata =null;
        //ObjectOutputStream senddata=null;
        try {
            getdata = new ObjectInputStream(soc.getInputStream());
            //senddata=new ObjectOutputStream(soc.getOutputStream());
            int cnt=0;
            while(true) {


                //System.out.println("got data...");
                packets pac = (packets) getdata.readObject();
                if(cnt==0 && algoname.equals("WFQ")){


                    //System.out.println("cnt==0 : flwgt --> "+pac.flow_w);
                    ProgrammableSwitch.totalweights_sum=ProgrammableSwitch.totalweights_sum+pac.flow_w;
                    ProgrammableSwitch.fairshare=ProgrammableSwitch.bandwidth/ProgrammableSwitch.totalweights_sum;
                    //System.out.println(ProgrammableSwitch.totalweights_sum);
                    //System.out.println(ProgrammableSwitch.fairshare);
                    cnt++;
                    continue;

                }


                //packets pac = (packets) getdata.readObject();

                if(pac.fname.equals("done")) {
                    //System.out.println("in breaking condition...");
                    schalgo.display();
                    break;
                }




                pac.arrival_time=(System.currentTimeMillis()-start_time)/1000;

                //System.out.println("pac arrival tym: "+pac.arrival_time);
                synchronized (schalgo) {

                    //System.out.println("in sync");
                    schalgo.invokeAlgo(algoname,pac,prev_pac);
                }

                prev_pac=pac;

                //senddata.writeUTF("received object");



            }
        }
        catch(Exception e){
            e.printStackTrace();
        }

        finally {
            try {
                if (getdata != null) getdata.close();
                soc.close();
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }

    }


}
