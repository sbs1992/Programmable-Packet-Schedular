import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.TreeMap;

public class SchedulingAlgorithms {

    TreeMap<Double, ArrayList<packets>> scheduleorder=new TreeMap<Double, ArrayList<packets>>();

    static int packet_count=0;
    static int define_length=10;


    public void callWFQ(packets packet,packets prev_pkt){

        //System.out.println("call WFQ invoked");

           if(prev_pkt==null){

               packet.virtual_finish_time=packet.arrival_time+((packet.psize)/ProgrammableSwitch.fairshare);
           }
           else{

               packet.virtual_finish_time=Math.max(packet.arrival_time,prev_pkt.virtual_finish_time)+((packet.psize)/ProgrammableSwitch.fairshare);
           }




           if(!scheduleorder.containsKey(packet.virtual_finish_time)){
               ArrayList<packets> pkt_list=new ArrayList<>();
               pkt_list.add(packet);
               scheduleorder.put(packet.virtual_finish_time,pkt_list);
           }
           else{

               scheduleorder.get(packet.virtual_finish_time).add(packet);

           }

           packet_count++;

           if(packet_count==define_length){

               display();
           }




    }


    public void display(){
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("scheduleorder.txt",true));

            ArrayList<String> order = new ArrayList<>();
            for (double d : scheduleorder.keySet()) {

                for (packets pc : scheduleorder.get(d)) {
                    //System.out.println(pc.virtual_finish_time);
                    //System.out.println(pc.psize);
                    String sout = pc.fname + ":" + pc.pnumber;
                    order.add(sout);
                }

            }

            for (String sdis : order) {
                //System.out.print(sdis + " ");
                bw.write(sdis+" ");
            }
            bw.write("\n");
            bw.close();
            //System.out.println();


            //reinitializing for the next set of packets
            packet_count = 0;

            scheduleorder = new TreeMap<Double, ArrayList<packets>>();

        }
        catch(Exception e){

            e.printStackTrace();
        }
    }

    public void invokeAlgo(String algoname,packets packet,packets prev_pkt){

        switch (algoname){

            case "WFQ": callWFQ(packet,prev_pkt);break;
            default: System.out.println("cannot find the scehduling algorithm selected");break;
        }


    }

}
